# Task 5 - Flutter UI

## How to Run

```bash
flutter pub get
flutter run
```

## Features
- AppBar with title
- Profile image (CircleAvatar)
- Welcome text
- Star icon
- Email & Password TextFields
- Submit button
- FloatingActionButton
